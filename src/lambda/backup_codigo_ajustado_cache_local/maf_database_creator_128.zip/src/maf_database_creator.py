import time
from denethor.core import denethor_logger as dlh
from denethor.utils import aws_utils as dau
import maf_database_creator_core as mdcc
from denethor.utils import file_utils as dfu, utils as du
import os, sys, logging
import os, boto3, timeit, logging
from denethor.utils import utils as du
from denethor import constants as const

def handler(event, context):
    
    
    ##
    # Auxiliar and Validation Functions
    ##
    def calculate_total_files_and_size(files: list, path: str) -> tuple[int, int]:
        """
        Get file metadata from a directory.
        Args:
            files (list): List of file names to check.
            path (str): Path to the directory.
        Returns:
            tuple: Total file count and total file size.
        """
        if not os.path.exists(path):
            raise ValueError(f"Path {path} does not exist!")
        if not os.path.isdir(path):
            raise ValueError(f"Path {path} is not a directory!")
        if not files:
            raise ValueError(f"Files list is empty!")
        
        file_names = []
        total_file_count = 0
        total_file_size = 0
        for file in os.listdir(path):
            fp = os.path.join(path, file)
            if os.path.isfile(fp) and (files is None or file in files):
                total_file_count += 1
                total_file_size += os.path.getsize(fp)
                file_names.append(file)
        
        return total_file_count, total_file_size

    def get_file_size(file_path: str) -> int:
        """
        Retrieve the size of a file in bytes.
        Args:
            file_path (str): Path to the file.
        Returns:
            int: Size of the file in bytes.
        """
        if not os.path.exists(file_path):
            raise ValueError(f"File {file_path} does not exist!")
        if not os.path.isfile(file_path):
            raise ValueError(f"Path {file_path} is not a file!")
        
        return os.path.getsize(file_path)
    
    ##
    # Download single file from S3
    ##
    def download_single_file_from_s3(file_name: str, 
                                    file_path: str, 
                                    s3_bucket: str, 
                                    s3_key: str) -> float:

        start_time = timeit.default_timer()
        
        validade_required_params(file_name, file_path, s3_bucket)
        
        # dependendo da forma que a requisição é feita, o nome do arquivo pode já estar incluso na s3_key
        if not s3_key.endswith(file_name):
            s3_key = os.path.join(s3_key, file_name)

        local_file = os.path.join(file_path, file_name)

        s3.download_file(s3_bucket, s3_key, local_file)
        
        end_time = timeit.default_timer()
        download_duration_ms = (end_time - start_time) * 1000

        return download_duration_ms



    def handle_consumed_files(request_id: str, 
                            provider: str,
                            file_list: list, 
                            file_path_local: str, 
                            s3_bucket: str,
                            s3_key: str,
                            logger: logging.Logger) -> None:
        total_transfer_duration_ms = 0
        file_list_flat = du.flatten_list(file_list)
        
        # Download file from s3 bucket into lambda function
        for file_name in file_list_flat:
            duration_ms = 0
            file_path_local_full = os.path.join(file_path_local, file_name)
            file_path_s3_full = os.path.join(s3_key, file_name)
            
            if provider == "aws_lambda":

                # se o arquivo estiver disponível localmente, não fazer o download,
                # mas copiar para o file_path_local
                file_subtree = os.path.join("subtree_files", file_name)  
                if os.path.exists(file_subtree):
                    os.system(f"cp {file_subtree} {file_path_local_full}")
                    logger.info(f"File {file_name} already exists in local path. Skipping download.")
                    duration_ms = 0
                else:
                    duration_ms = download_single_file_from_s3(file_name, file_path_local, s3_bucket, s3_key)
                    total_transfer_duration_ms += duration_ms
            
            file_size = get_file_size(file_path_local_full)
            logger.info(f"FILE_TRANSFER RequestId: {request_id}\t TransferType: consumed\t Action: download_from_s3\t FileName: {file_name}\t Bucket: {s3_bucket}\t FilePath: {file_path_s3_full}\t FilePathLocal: {file_path_local}\t FileSize: {file_size} bytes\t TransferDuration: {duration_ms} ms")
    
        total_files_count, total_files_size = calculate_total_files_and_size(file_list_flat, file_path_local)      
        logger.info(f"CONSUMED_FILES_INFO RequestId: {request_id}\t FilesCount: {total_files_count} files\t FilesSize: {total_files_size} bytes\t TransferDuration: {total_transfer_duration_ms} ms\t ConsumedFiles: {file_list_flat}")
  



    request_id = du.resolve_request_id(context)
    execution_tag = event.get('execution_tag')
    provider = event.get('provider')
    activity = event.get('activity')
    
    previous_activity = event.get('previous_activity')
    if previous_activity is None:
        input_files_props_sufix = 'input_files'
    else:
        input_files_props_sufix = previous_activity
    
    index_data = event.get('index_data')
    if index_data is None:
        input_files = event.get('input_data')
    else:
        input_files = event.get('input_data')[index_data]
    
    env_props = event.get('env_properties')
    s3_bucket = env_props.get('bucket').get('name')
    s3_key_input  = env_props.get('bucket').get('key.' + input_files_props_sufix)
    s3_key_output = env_props.get('bucket').get('key.' + activity)
    
    # Format of the sequences: newick or nexus
    DATA_FORMAT = env_props.get(provider).get('data_format') 

    TMP_PATH = env_props.get(provider).get('path.tmp') # usado para escrever arquivos 'nopipe' durante o processo de validação
    INPUT_PATH = env_props.get(provider).get('path.' + input_files_props_sufix)
    OUTPUT_PATH = env_props.get(provider).get('path.' + activity)
    CLUSTALW_PATH = env_props.get(provider).get('path.clustalw')

    logger = dlh.get_logger(execution_tag, provider, activity, env_props)
    
    # Cleaning old temporary files and creating directories ##
    # dfu.remove_files(TMP_PATH)
    dfu.create_directory_if_not_exists(INPUT_PATH, OUTPUT_PATH, TMP_PATH)
    
    # Use the full input data list tp create the MAF database
    compare_subtree_matrix = event.get('input_data')

    # Download input files ##
    #dau.handle_consumed_files(request_id, provider, compare_subtree_matrix, INPUT_PATH, s3_bucket, s3_key_input)
    handle_consumed_files(request_id, provider, compare_subtree_matrix, INPUT_PATH, s3_bucket, s3_key_input, logger)


    # Creation of the subtree similarity dictionary (maf database) ##
    produced_files, maf_duration_ms = mdcc.maf_database_creator(input_files, compare_subtree_matrix, INPUT_PATH, OUTPUT_PATH, DATA_FORMAT)
    logger.info(f'MAF_DATABASE_CREATOR RequestId: {request_id}\t Duration: {maf_duration_ms} ms\t InputSubtrees: {input_files}\t MafDatabaseFile: {produced_files}')
    
    # para evitar: 'PermissionError: [Errno 13] Permission denied' ao tentar abrir os arquivos logo após terem sido escritos
    time.sleep(0.100)
    
    # Upload output files ##
    dau.handle_produced_files(request_id, provider, produced_files, OUTPUT_PATH, s3_bucket, s3_key_output)
    
    return {
            "request_id" : request_id,
            "data" : produced_files
        }