import os, sys, logging

def get_simple_logger(file_name: str, file_path: str) -> tuple[logging.Logger, str]:
    """
    Cria um logger simples que registra mensagens em um arquivo e na saída padrão.
    """
    logger = logging.getLogger(file_name)
    logger.setLevel(logging.DEBUG)

    # Define o formato do log
    formatter = logging.Formatter(
        "[%(levelname)s] %(asctime)s.%(msecs)03dZ %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    # Configuração do arquivo de log
    log_file_path = os.path.join(file_path, file_name)
    file_handler = logging.FileHandler(log_file_path)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # Configuração da saída padrão
    # stream_handler = logging.StreamHandler(sys.stdout)
    # stream_handler.setFormatter(formatter)
    # logger.addHandler(stream_handler)

    return logger, log_file_path
